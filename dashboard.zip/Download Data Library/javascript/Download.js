(function () {
    "use strict";
    window.DownloadWithJSLI = function download(dataurl) {
        window.location.assign(dataurl);
    };
})();
